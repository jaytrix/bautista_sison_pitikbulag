var game = new Phaser.Game(400, 500, Phaser.CANVAS, 'gameDiv');


var bg;
var back;
var restart;
var talo;
var bgMusic;
var bgMusic;


var mainState = {

preload:function(){

    game.scale.scaleMode = Phaser.ScaleManager.SHOW_ALL;
    game.scale.pageAlignHorizontally = true;
    game.scale.pageAlignVertically = true;

    game.load.image("bg","img/bg1.png");  
    game.load.image("back","img/menu.png"); 
    game.load.image("restart","img/restart.png"); 
    game.load.image("talo","img/lose.png"); 

            game.load.audio("bgMusic","audio/audio.wav");



   
},

create: function(){ 
    game.physics.startSystem(Phaser.Physics.ARCADE);
        
    game.add.image(0,0,"bg");

     bgMusic = game.add.audio("bgMusic",1,true);
            bgMusic.play();

    back = game.add.button (0,430,"back",balik);
    back.scale.x= .7;
    back.scale.y= .7;

    restart = game.add.button (262,430,"restart", uliten);
    restart.scale.x= .7;
    restart.scale.y= .7;

    talo = game.add.button (50,250,"talo");
    talo.scale.x= .7;
    talo.scale.y= .7;

},
update: function () {
},
audioloop:function()
        {
            setInterval(function(){
                bgMusic.play();
            },5000)
        }

}
    function balik ()
    {
      window.location.href="level.html";
    }
    function uliten ()
    {
        window.location.href="dos.html";
    }
    game.state.add("mainState",mainState);
    game.state.start("mainState");