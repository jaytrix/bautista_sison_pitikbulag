var game = new Phaser.Game(400, 500, Phaser.CANVAS, 'gameDiv');


var bg;
var back;
var button;
var button1;
var button2;
var choose;
var restart;
var tao;
var timeText;
var stateText;
var bgMusic;


var mainState = {

preload:function(){

    game.scale.scaleMode = Phaser.ScaleManager.SHOW_ALL;
    game.scale.pageAlignHorizontally = true;
    game.scale.pageAlignVertically = true;

    game.load.image("bg","img/bg.png");  
    game.load.image("back","img/menu.png"); 
    game.load.image("tao","img/tao1.png");       
    game.load.image("button","img/button.png");    
    game.load.image("button1","img/button1.png");    
    game.load.image("button2","img/button2.png");    
    game.load.image("choose","img/choose.png"); 
    game.load.image("restart","img/restart.png");

                game.load.audio("bgMusic","audio/audio.wav");

},

create: function(){ 
    game.physics.startSystem(Phaser.Physics.ARCADE);

    timer(5,0500);//secs of timer

     bgMusic = game.add.audio("bgMusic",1,true);
            bgMusic.play();
        
    game.add.image(0,0,"bg");
    back = game.add.button (0,450,"back",balik);
    back.scale.x= .5;
    back.scale.y= .5;

    choose = game.add.image(0,280,"choose");

    button = game.add.button (50,320,"button", unayabutton);
    button.scale.x= .5;
    button.scale.y= .5;

    button1 = game.add.button (150,320,"button1", kumadwayabutton);
    button1.scale.x= .5;
    button1.scale.y= .5;

    button2 = game.add.button (250,320,"button2", kumatloyabutton);
    button2.scale.x= .5;
    button2.scale.y= .5;

    restart = game.add.button(300,450, "restart", restart);
    restart.scale.x= .5;
    restart.scale.y= .5;

    tao = game.add.button(-30,80, "tao", galaw);
    tao.scale.x= 2;
    tao.scale.y= 2;

    timeText = game.add.text(150,450,"Time: 10",{font: '34px ARIAL', fill:"blue"});//timer text
    stateText = game.add.text(game.world.centerX,game.world.centerY,' ', { font: '64px GOTHIC', fill: 'yellow' });
    stateText.anchor.setTo(0.5, 0.5);
    stateText.visible = false;
},
update: function () {
},
audioloop:function()
        {
            setInterval(function(){
                bgMusic.play();
            },5000)
        }

}
    function balik ()
    {
      window.location.href="level.html";
    }
    function unayabutton ()
    {
        window.location.href="kumadwayabutton.html";
    }
     function kumadwayabutton ()
    {
        window.location.href="kumadwayabutton.html";
    }
     function kumatloyabutton ()
    {
        window.location.href="kumadwayabutton.html";
    }
    
    function galaw ()
    {
         setTimeout(function(){
                tao.frame = 0;

            },3000);

            //tao.frame = 1;
    }
    function timer(initTime,microsec){
            setInterval(function(){
            initTime--;
            if(initTime>=0){        
                timeText.text = "Time: "+initTime;
            }
            else{
                game._paused = true;
                stateText.text=" TIMES UP!! ";
                stateText.visible = true;
                }
            },microsec);
            game.input.onTap.addOnce(restart,this);

        }
        function restart ()
    {
        window.location.href= "tres.html";
    }
    game.state.add("mainState",mainState);
    game.state.start("mainState");