var game = new Phaser.Game(400, 500, Phaser.CANVAS, 'gameDiv');


var bg;
var back;
var trixie;
var alex;
var section;
var syak;
var sikato;

var mainState = {

preload:function(){

    game.scale.scaleMode = Phaser.ScaleManager.SHOW_ALL;
    game.scale.pageAlignHorizontally = true;
    game.scale.pageAlignVertically = true;

    game.load.image("bg","img/set1.png");  
    game.load.image("back","img/menu.png"); 
    game.load.image("trixie","img/trixie.png"); 
    game.load.image("alex","img/alex.png"); 
    game.load.image("section","img/section.png"); 
    game.load.image("syak","img/ming.jpg"); 
    game.load.image("sikato","img/lex.jpeg"); 

    },

create: function(){ 
    game.physics.startSystem(Phaser.Physics.ARCADE);
        
    bg = game.add.tileSprite(0,0,800,600, "bg");

    back = game.add.button (0,430,"back",balik);
    back.scale.x= .7;
    back.scale.y= .7;

    trixie = game.add.image(00,250,"trixie");
    trixie.scale.x= .5;
    trixie.scale.y= .5;

    alex = game.add.image(215,250,"alex");
    alex.scale.x= .5;
    alex.scale.y= .5;

    section = game.add.image(0,340,"section");
    section.scale.x= .5;
    section.scale.y= .5;

    syak = game.add.image(0,0,"syak");
    syak.scale.x= .1;
    syak.scale.y= .1;

    sikato = game.add.image(200,295,"sikato");
    sikato.scale.x= .2;
    sikato.scale.y= .2;



},
update: function () {
    bg.tilePosition.x -=.5;
}
}
    function balik ()
    {
      window.location.href="index.html";
    }
    game.state.add("mainState",mainState);
    game.state.start("mainState");