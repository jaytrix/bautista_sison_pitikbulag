var game = new Phaser.Game(400, 500, Phaser.CANVAS, 'gameDiv');

var bg;
var easy;
var medium;
var hard;
var back;




var mainState =

    {

        preload:function()
        {
            game.scale.scaleMode = Phaser.ScaleManager.SHOW_ALL;
            game.scale.pageAlignHorizontally = true;
            game.scale.pageAlignVertically = true;

            game.load.image("bg","img/set1.png");
            game.load.image("medium","img/medium.png");
            game.load.image("easy","img/easy.png");
            game.load.image("hard","img/hard.png");
            game.load.image("back","img/menu.png"); 

        },
        create:function()
        {
            bg = game.add.tileSprite(0,0,800,600, "bg");
            easy = game.add.button(40,100,"easy", easy);
            easy.scale.x = .8;
            easy.scale.y = .8;
            medium = game.add.button(40,200,"medium", medium);
            medium.scale.x = .8;
            medium.scale.y = .8;
            hard = game.add.button(40,300,"hard", hard  );
            hard.scale.x = .8;
            hard.scale.y = .8;

            back = game.add.button (0,430,"back",balik);
            back.scale.x= .7;
            back.scale.y= .7;

        },


        update:function ()
        {
            bg.tilePosition.x -=.3;
        },
    }
        function balik ()
        {
            window.location.href="index.html";
        }
        function easy ()
        {
            window.location.href="uno.html";
        }
        function medium ()
        {
            window.location.href="dos.html";
        }
        function hard ()
        {
             window.location.href="tres.html";

        }


    game.state.add("mainState",mainState);
    game.state.start("mainState");