var game = new Phaser.Game(400, 500, Phaser.CANVAS, 'gameDiv');

var bg;
var bgMusic;
var start;
var about;
var name;
var mute;



var mainState =

    {

        preload:function()
        {
            game.scale.scaleMode = Phaser.ScaleManager.SHOW_ALL;
            game.scale.pageAlignHorizontally = true;
            game.scale.pageAlignVertically = true;

            game.load.image("bg","img/set1.png");
            game.load.image("name","img/name.png");
            game.load.image("start","img/play.png");
            game.load.image("mute","img/mute.png");
            game.load.image("about","img/about.png");

            game.load.audio("bgMusic","audio/audio.wav");
        },
        create:function()
        {
            bg = game.add.tileSprite(0,0,800,600, "bg");
            bgMusic = game.add.audio("bgMusic",1,true);
            bgMusic.play();
            name = game.add.image(0,100,"name");
            start = game.add.button(100,250,"start",umpisa);
            about = game.add.button(100,370,"about",about);
            mute = game.add.image(350,0,"mute",silent);
        },


        update:function ()
        {
            bg.tilePosition.x -=.1;
        },

        audioloop:function()
        {
            setInterval(function(){
                bgMusic.play();
            },5000)
        }
    }
        function umpisa ()
        {
            window.location.href="level.html";
        }
        function about ()
        {
            window.location.href="about.html";
        }
        function silent ()
        {
            bgMusic.stop();
        }


    game.state.add("mainState",mainState);
    game.state.start("mainState");